﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Tutoring.professor
{
    public partial class activitying : System.Web.UI.Page
    {
        //int index;

        protected void Page_Load(object sender, EventArgs e)
        {
            //index = Int32.Parse(Request.QueryString["index"]);
        }
    }
}